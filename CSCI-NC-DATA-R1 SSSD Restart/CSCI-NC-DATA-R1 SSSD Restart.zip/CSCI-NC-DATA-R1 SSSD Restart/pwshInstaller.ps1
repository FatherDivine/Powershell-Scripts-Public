﻿if (!(Test-Path "C:\Program Files\PowerShell\7\pwsh.exe"))
{ winget install --id Microsoft.Powershell --source winget --force
}
# Pre-trust the server to bypass the "authenticity of hosts can't be established" prompt
ssh-keyscan csci-nc-data-r1 >> $HOME/.ssh/known_hosts