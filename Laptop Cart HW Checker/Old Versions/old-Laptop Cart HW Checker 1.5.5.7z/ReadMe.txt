Welcome to version 1.5.5 of LCHWC!

If you would like to work with modified versions of LCHWC, we encourage you to well document the changes of the script.

------------------------------------------------------------
Table of Contents
------------------------------------------------------------
   I	Additional Support
  II	File List
 III	Requirements
  IV	Command Line Arguments
   V	Design Decisions & Issues
  VI	Analysis
 VII	Expected /real Bottlenecks
VIII	THE STORY SO FAR
  IX	Design & Implementation
   X	Credits
------------------------------------------------------------
I Additional support
------------------------------------------------------------

If you are looking for external help, look no further than the e-mail! aaron.staten@ucdenver.edu.

-------------------------
II File list
-------------------------
LCHWC-1.5.5.bat		  The main file
LCHWCMailer.ps1		  Powershell script used to e-mail the hardware comparison results
LCHWC - Change Notes.txt  All change notes
Readme.txt		  This file


----------------------
III Requirements
----------------------
Native windows environment


----------------------
IV Command Line Arguments
----------------------
Nada


-------------------------
V Design Decisions & Issues
-------------------------
A. Program design

1. Style


-------------------------
VI Analysis
-------------------------


-------------------------
VII Expected /real Bottlenecks
-------------------------


------------------------------------------------------------
VIII THE STORY SO FAR
------------------------------------------------------------

You're IT staff, one of Earth's toughest, hardend in repair and trained for success. Three years ago your superior officers had a meeting and requested sofware to document changes to laptop hardware. As evil can sometime come out of the Gateways, you were ordered to secure the perimeter of the base, which includes the laptop hardware. 

------------------------------------------------------------
IX Design & Implementation
------------------------------------------------------------
For the sake of integrity as well as knowing the condition of our own hardware best, the idea of a script to document laptop hardware was born. 

In designing this script, there were a few goals we had in mind. The ability to record the state of a laptop's hardware prior to being rented, record again when brought back, and compare any differences between the two list. Another was to make this as automated as possible, with minimal tech intervention. Discreetness was baked in to add tamper-resistance of those using the laptops. Another goal was to keep this as native as possible, requiring no additional software installation on the laptops. Lastly, plenty of commentary was baked in all files to create a model for other scripts that may come, as well as to clearlly communicate what each part does.

The script starts with an "admin rights" script to gain the rights needed. When executing the script, expect a UAC pop-up that needs to be clicked "yes" to here. Because of it's automation nature, the script automatically pulls the hardware using "wmic" commands and stores them in a file called "PreHardware

------------------------------------------------------------
X Credits
------------------------------------------------------------