﻿#This version is made for a snapin pack containing Cred.xml & Key.xml
Start-Transcript -Path "${PSScriptRoot}\TranscriptJoin.txt"

# Variables
$hn = $env:COMPUTERNAME

# The Secure credential version
try{
    $key = Import-Clixml -LiteralPath ${PSScriptRoot}\Key.xml
    $importObject = Import-Clixml -LiteralPath ${PSScriptRoot}\Cred.xml
    $secureString = ConvertTo-SecureString -String $importObject.Password -Key $key
    $Credential = New-Object System.Management.Automation.PSCredential($importObject.UserName, $secureString)   
    }catch{Write-Error “`nAn error occurred: $($_.Exception.Message)`n"}

# LOGIC to dessimate hostname and figure out correct OU path



# LOGIC to pull service tag, sanitize it, and add to description in AD
$ServiceTag = Get-CimInstance -ErrorAction Stop win32_SystemEnclosure | select-object serialnumber
$ST = $ServiceTag -Replace ('\W','')
$ST2 = $ST -Replace ('serialnumber','')

# Add PC to AD in correct OU
Add-Computer -DomainName "ucdenver.pvt" -OUPATH "OU=NC2413,OU=LABS,OU=CEAS,DC=ucdenver,DC=pvt" -Force -Credential $Credential -Verbose

#Tag the AD PC Object with its Service Tag
Set-ADObject -Identity "CN=$hn,OU=NC2413,OU=LABS,OU=CEAS,DC=ucdenver,DC=pvt" -Description "Service Tag: $ST2" -Credential $Credential -Verbose
Stop-Transcript
exit