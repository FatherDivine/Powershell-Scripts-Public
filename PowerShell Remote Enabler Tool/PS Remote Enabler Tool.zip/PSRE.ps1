﻿<#
  .SYNOPSIS
    Enable PS-Remoting remotely.

  .DESCRIPTION
    The PSRE.ps1 script allows the user to enable PS-Remoting on a list 
    of remote computers. It takes input from a file called "computers.txt"
    and runs an enable PS-Remoting command thru PSExec.exe, Both files 
    are in the same folder as the PSRE.ps1 script, and must be to work.

  .PARAMETER Server
    Allows to pipe a hostname/IP address to the Enable PS Remoting command
    via the command prompt/PS. Specifically used by the Dell Service Tag 
    Puller Tool (DSTP.ps1) to enable PS Remoting before the second attempt
    at pulling the service tag remotely.
  .PAREMETER ServerList
    Allows to pipe the filename of a list of computers to have PS Enabler
    run on. Can set  folder by specifying "Folder\File.txt" as the answer.

  .LINK
    \\DATA\DEPT\CEAS\ITS\Software\Scripts\PS Remote Enabler Tool
  
  .INPUTS
    A -Server flag can be piped into PSRE.ps1 (or any other script). Here's an example:
    
    .\PSRE.ps1 -Server "$Hostname here"
    
    And in the case of inside another script:
    & ${PSScriptRoot}\PSRE.ps1 -Server Host-Name-Here
    
    Once that input is detected by PSRE.ps1, the Enable-PSRemoting
    command is launched using PsExec.exe and the piped $Server.

    A -ServerList flag can be piped into PSRE.ps1 as well. Here's an example:

    .\PSRE.ps1 -ServerList "Folder\computerlist.txt"

    And in the case of accessing inside another script:
    & ${PSScriptRoot}\PSRE.ps1 -ServerList "computers.txt"

  .OUTPUTS
    None. But PSRE.ps1 may one day output to ${PSScriptRoot}\OfflinePCs.txt
    to record PCs not online. More work has to be done on a method that can
    achieve this.

  .EXAMPLE
    PS> .\PSRE.ps1

  .Author
    Created by Aaron S. for CU Denver CEDC IT Dept

  .To-do
    Add the command to enable PS script execution on all listed PCs too. 2 birds with one stone! (Execution policy: powershell -NoProfile -ExecutionPolicy Bypass)
    Also add the catch back (using finding exceptions for catch.ps1      
 #>
                                        #This first Param statement allows to use pipeline -Server from command line. ex: .\PSRE.ps1 -Server "hostname"
Param
       (
       [Parameter(Mandatory=$false,
       ValueFromPipeline=$true)]
       [string]$Server=$NULL,
       $errorlog,

       [Parameter(Mandatory=$false,
       ValueFromPipeline=$true)]
        [string]
        $ServerList=$NULL
       )  
if ($PSBoundParameters.ContainsKey('Server'))
{
                                        #Credentials section for use at home. Not needed at the University.
                                        #But also good to have silent test for credentials anyway in all tools.
If ((Test-Path ${PSScriptRoot}\Key.xml -ErrorAction SilentlyContinue) -and (Test-Path ${PSScriptRoot}\Cred.xml -ErrorAction SilentlyContinue))
{
 $key = Import-Clixml -LiteralPath ${PSScriptRoot}\Key.xml
 $importObject = Import-Clixml -LiteralPath ${PSScriptRoot}\Cred.xml
 $secureString = ConvertTo-SecureString -String $importObject.Password -Key $key
 $Credential = New-Object System.Management.Automation.PSCredential($importObject.UserName, $secureString)
 $UserName = $Credential.UserName
 $Password = $Credential.GetNetworkCredential().Password
 $CredentialFile = '1'
}else{continue}
If ($CredentialFile -eq '1'){try{& ${PSScriptRoot}\PsExec.exe \\$Server -accepteula  -u $username -p $password -h -s powershell.exe Enable-PSRemoting -Force}catch{Write-Error “`nAn error occurred: $($_.Exception.Message)`n”}}
else {try{& ${PSScriptRoot}\PsExec.exe \\$Server -accepteula -h -s powershell.exe Enable-PSRemoting -Force}catch{Write-Error “`nAn error occurred: $($_.Exception.Message)`n”}}
exit
}
if ($PSBoundParameters.ContainsKey('ServerList'))
{
                                        #Credentials section for use at home. Not needed at the University.
                                        #But also good to have silent test for credentials anyway in all tools. 
If ((Test-Path ${PSScriptRoot}\Key.xml -ErrorAction SilentlyContinue) -and (Test-Path ${PSScriptRoot}\Cred.xml -ErrorAction SilentlyContinue))
{
 $key = Import-Clixml -LiteralPath ${PSScriptRoot}\Key.xml
 $importObject = Import-Clixml -LiteralPath ${PSScriptRoot}\Cred.xml
 $secureString = ConvertTo-SecureString -String $importObject.Password -Key $key
 $Credential = New-Object System.Management.Automation.PSCredential($importObject.UserName, $secureString)
 $UserName = $Credential.UserName
 $Password = $Credential.GetNetworkCredential().Password
 $CredentialFile = '1'
}else{continue}
If ($CredentialFile -eq '1')
{try{
 $wks = Get-Content "${PSScriptRoot}\$ServerList"
 foreach($ws in $wks){
                      & ${PSScriptRoot}\PsExec.exe \\$ws -accepteula  -u $username -p $password -h -s powershell.exe Enable-PSRemoting -Force        
                     } 
}catch{Write-Error “`nAn error occurred: $($_.Exception.Message)`n”}}
else{try{
     $wks = Get-Content "${PSScriptRoot}\$ServerList"
     foreach($ws in $wks){
     & ${PSScriptRoot}\PsExec.exe \\$ws -accepteula -h -s powershell.exe Enable-PSRemoting -Force        
                         }
    }catch{Write-Error “`nAn error occurred: $($_.Exception.Message)`n”}}
exit
}
                                        #Couldn't allow the above using the below. The below is the function the script uses.
 function Enable-PSRemote{
 [cmdletbinding()]
Param
       (
       [Parameter(Mandatory=$false,
       ValueFromPipeline=$true)]
       [string]$Server=$NULL,
       $errorlog,
       [Parameter(Mandatory=$false,
       ValueFromPipeline=$true
        )]
        [string]
        $ServerList=$NULL,
        [Parameter(

        )]
        [string]
        $ParamThree
       )
begin {

        #setup our return object
        $result = [PSCustomObject]@{

            SuccessOne = $false
            SuccessTwo = $false
        }        
    }
    process {
                                        #use a switch statement to take actions based on passed in parameters
        switch ($PSBoundParameters.Keys) {
            'Server' {
                                        #perform actions if ParamOne is used
                If ((Test-Path ${PSScriptRoot}\Key.xml -ErrorAction SilentlyContinue) -and (Test-Path ${PSScriptRoot}\Cred.xml -ErrorAction SilentlyContinue))
                {
                $key = Import-Clixml -LiteralPath ${PSScriptRoot}\Key.xml
                $importObject = Import-Clixml -LiteralPath ${PSScriptRoot}\Cred.xml
                $secureString = ConvertTo-SecureString -String $importObject.Password -Key $key
                $Credential = New-Object System.Management.Automation.PSCredential($importObject.UserName, $secureString)
                $UserName = $Credential.UserName
                $Password = $Credential.GetNetworkCredential().Password
                $CredentialFile = '1'
                }else{continue}
                If ($CredentialFile -eq '1'){try{& ${PSScriptRoot}\PsExec.exe \\$Server -accepteula  -u $username -p $password -h -s powershell.exe Enable-PSRemoting -Force}catch{Write-Error “`nAn error occurred: $($_.Exception.Message)`n”}}
                else {try{& ${PSScriptRoot}\PsExec.exe \\$Server -accepteula -h -s powershell.exe Enable-PSRemoting -Force}catch{Write-Error “`nAn error occurred: $($_.Exception.Message)`n”}}
                $result.SuccessOne = $true   
                     }
            'ServerList' {
                                        #perform logic if ParamTwo is used
                If ((Test-Path ${PSScriptRoot}\Key.xml -ErrorAction SilentlyContinue) -and (Test-Path ${PSScriptRoot}\Cred.xml -ErrorAction SilentlyContinue))
                {
                $key = Import-Clixml -LiteralPath ${PSScriptRoot}\Key.xml
                $importObject = Import-Clixml -LiteralPath ${PSScriptRoot}\Cred.xml
                $secureString = ConvertTo-SecureString -String $importObject.Password -Key $key
                $Credential = New-Object System.Management.Automation.PSCredential($importObject.UserName, $secureString)
                $UserName = $Credential.UserName
                $Password = $Credential.GetNetworkCredential().Password
                $CredentialFile = '1'
                }else{continue}
                If ($CredentialFile -eq '1'){try{
                Write-Host "`nGoing thru ${PSScriptRoot}\$ServerList..."
                $wks = Get-Content "${PSScriptRoot}\$ServerList"
                foreach($ws in $wks){
                & ${PSScriptRoot}\PsExec.exe \\$ws -accepteula  -u $username -p $password -h -s powershell.exe Enable-PSRemoting -Force}}catch{Write-Error “`nAn error occurred: $($_.Exception.Message)`n”}}
                else {try{
                Write-Host "`nGoing thru ${PSScriptRoot}\$ServerList..."
                $wks = Get-Content "${PSScriptRoot}\$ServerList" 
                foreach ($ws in $wks){
                & ${PSScriptRoot}\PsExec.exe \\$Server -accepteula -h -s powershell.exe Enable-PSRemoting -Force}}catch{Write-Error “`nAn error occurred: $($_.Exception.Message)`n”}}
                $result.SuccessTwo = $true
                         }
            Default {
                
                Write-Warning "Unhandled parameter -> [$($_)]"
                    }
                                         }        
    }
    end {

        #return $result
    }}
function Intro
{
$t = @'
  _______ _
 |__   __| |
    | |  | |__   ___
    | |  | '_ \ / _ \
    | |  | | | |  __/
    |_|  |_| |_|\___|
  _____   _____   _____                      _
 |  __ \ / ____| |  __ \                    | |
 | |__) | (___   | |__) |___ _ __ ___   ___ | |_ ___
 |  ___/ \___ \  |  _  // _ \ '_ ` _ \ / _ \| __/ _ \
 | |     ____) | | | \ \  __/ | | | | | (_) | ||  __/
 |_|    |_____/  |_|  \_\___|_| |_| |_|\___/ \__\___|
  ______             _     _             _______          _ 
 |  ____|           | |   | |           |__   __|        | |
 | |__   _ __   __ _| |__ | | ___ _ __     | | ___   ___ | |
 |  __| | '_ \ / _` | '_ \| |/ _ \ '__|    | |/ _ \ / _ \| |
 | |____| | | | (_| | |_) | |  __/ |       | | (_) | (_) | |
 |______|_| |_|\__,_|_.__/|_|\___|_|       |_|\___/ \___/|_|

'@

for ($i=0;$i -lt $t.length;$i++) {
if ($i%2) {
 $c = "white"
}
elseif ($i%5) {
 $c = "white"
}
elseif ($i%7) {
 $c = "white"
}
else {
   $c = "white"
}
write-host $t[$i] -NoNewline -ForegroundColor $c
}
}
Clear-Host;Intro
do{$Selection = Read-Host "`nDo you wish to Enable PS Remote on a (S)ingle hostname/IP or a (L)istfile?"} 
       while ($Selection -notmatch "^(L|S|Q)$")
       if ($Selection -eq 'L'){$Choice = 'L'}
       elseif ($Selection -eq 'S'){$Choice = 'S'}
       elseif ($Selection -eq 'Q'){exit}
       else{continue}

If ($Choice -eq 'L'){
Write-Host "`nPlease specify the name of a file located in the same folder as this script."
$Answer = Read-Host "If no name is specified, will default to ${PSScriptRoot}\computers.txt"
if (!$Answer){$Answer = 'computers.txt'}
                     Enable-PSRemote -ServerList $Answer        
                    }
elseif ($Choice -eq 'S'){
$HostPC = Read-Host "`nPlease type the hostname/IP you wish to enable remote PS on"
                     Enable-PSRemote -Server $HostPC        
                        }
pause